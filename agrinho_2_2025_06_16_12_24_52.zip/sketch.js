function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let perguntas = [
  "1️⃣ Qual é a principal contribuição do campo para a cidade?",
  "2️⃣ De que forma a cidade ajuda o desenvolvimento do campo?",
  "3️⃣ Por que é importante celebrar a conexão entre campo e cidade?",
  "4️⃣ O que acontece quando compramos produtos da agricultura familiar?",
  "5️⃣ Como a tecnologia das cidades beneficia o meio rural?",
  "6️⃣ Por que o bem-estar das cidades depende do campo?"
];

let alternativas = [
  ["A) Tecnologia e internet", "B) Alimentos e matérias-primas", "C) Serviços bancários", "D) Transporte público"],
  ["A) Oferecendo praias", "B) Fornecendo alimentos", "C) Tecnologia, serviços e comércio", "D) Espaços de lazer"],
  ["A) Competir", "B) Valorizar quem planta e consome", "C) Acabar com feiras", "D) Reduzir comércio local"],
  ["A) Enfraquecemos o comércio", "B) Fortalecemos campo e cidade", "C) Aumentamos a poluição", "D) Enriquecemos grandes empresas"],
  ["A) Diminuindo a produção", "B) Melhoria na produção e qualidade de vida", "C) Aumentando impostos", "D) Desvalorizando trabalho rural"],
  ["A) Oferece alimentos e recursos", "B) Fornece internet", "C) Produz carros", "D) Tem grandes indústrias"]
];

let respostas = [1, 2, 1, 1, 1, 0];

let estado = "inicio";
let perguntaAtual = 0;
let pontuacao = 0;
let feedback = "";

function setup() {
  createCanvas(700, 500);
  textAlign(CENTER, CENTER);
}

function draw() {
  if (estado === "inicio") {
    telaInicio();
  } else if (estado === "texto") {
    telaTexto();
  } else if (estado === "quiz") {
    telaQuiz();
  } else if (estado === "fim") {
    telaFim();
  }
}

function telaInicio() {
  background(150, 200, 255);
  textSize(36);
  fill(0);
  text("Quiz - Campo e Cidade 🌾🏙️", width / 2, height / 2 - 40);
  textSize(22);
  fill(50);
  text("Clique para começar", width / 2, height / 2 + 30);
}

function telaTexto() {
  background(240, 230, 200);
  fill(50, 50, 50);
  textSize(18);
  text(
    "O campo e a cidade estão conectados.\n" +
      "O campo fornece alimentos e recursos.\n" +
      "A cidade oferece tecnologia, comércio e serviços.\n" +
      "Quando compramos da agricultura familiar, fortalecemos essa união.\n" +
      "O bem-estar das cidades depende diretamente do campo.",
    width / 2,
    height / 2 - 50
  );

  fill(100, 200, 100);
  rect(width - 150, height - 60, 120, 40, 10);
  fill(255);
  textSize(20);
  text("Próximo", width - 90, height - 40);
}

function telaQuiz() {
  background(255, 245, 200);
  fill(0);
  textSize(20);
  text(perguntas[perguntaAtual], width / 2, 50);

  if (feedback != "") {
    fill(feedback === "acerto" ? "green" : "red");
    text(
      feedback === "acerto"
        ? "Parabéns pelo acerto 🎊"
        : "Você errou 🥹",
      width / 2,
      90
    );
  }

  for (let i = 0; i < 4; i++) {
    fill(180, 220, 250);
    rect(width / 2 - 150, 130 + i * 70, 300, 50, 12);
    fill(0);
    text(alternativas[perguntaAtual][i], width / 2, 155 + i * 70);
  }
}

function telaFim() {
  background(100, 180, 100);
  textSize(28);
  fill(255);
  text("🎉 Quiz Finalizado 🎉", width / 2, height / 2 - 50);
  text(
    "Pontuação: " + pontuacao + " de " + perguntas.length,
    width / 2,
    height / 2
  );
  text("Clique para jogar novamente", width / 2, height / 2 + 50);
}

function mousePressed() {
  if (estado === "inicio") {
    estado = "texto";
  } else if (estado === "texto") {
    if (
      mouseX > width - 150 &&
      mouseX < width - 30 &&
      mouseY > height - 60 &&
      mouseY < height - 20
    ) {
      estado = "quiz";
    }
  } else if (estado === "quiz") {
    for (let i = 0; i < 4; i++) {
      let x = width / 2 - 150;
      let y = 130 + i * 70;
      let w = 300;
      let h = 50;

      if (
        mouseX > x &&
        mouseX < x + w &&
        mouseY > y &&
        mouseY < y + h
      ) {
        if (i === respostas[perguntaAtual]) {
          pontuacao++;
          feedback = "acerto";
        } else {
          feedback = "erro";
        }

        setTimeout(() => {
          feedback = "";
          perguntaAtual++;
          if (perguntaAtual >= perguntas.length) {
            estado = "fim";
          }
        }, 700);
      }
    }
  } else if (estado === "fim") {
    perguntaAtual = 0;
    pontuacao = 0;
    estado = "inicio";
  }
}
